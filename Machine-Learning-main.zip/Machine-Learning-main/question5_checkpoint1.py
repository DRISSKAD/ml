import numpy as np
def func(arr):
    return arr.tolist()
arr=np.array([[1,2,3],[4,5,6]])
print(func(arr))
