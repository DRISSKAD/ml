def sqrdic(n):
    dic={i:i**2 for i in range(n+1)}
    return dic
